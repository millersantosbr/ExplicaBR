import { Card } from "@/components/ui/card"
import { FileText, Lightbulb, CheckCircle } from "lucide-react"

export function HowItWorks() {
  return (
    <div className="grid md:grid-cols-3 gap-8">
      <Card className="p-6 text-center flex flex-col items-center">
        <div className="bg-blue-100 p-4 rounded-full mb-4 dark:bg-blue-900">
          <FileText className="h-10 w-10 text-blue-700 dark:text-blue-400" />
        </div>
        <h3 className="text-xl font-semibold mb-3">1. Insira o Conteúdo</h3>
        <p className="text-lg">Cole o texto ou anexe uma imagem/documento oficial que você precisa entender.</p>
      </Card>

      <Card className="p-6 text-center flex flex-col items-center">
        <div className="bg-blue-100 p-4 rounded-full mb-4 dark:bg-blue-900">
          <Lightbulb className="h-10 w-10 text-blue-700 dark:text-blue-400" />
        </div>
        <h3 className="text-xl font-semibold mb-3">2. Processamento</h3>
        <p className="text-lg">
          Nossa inteligência artificial analisa o texto e identifica os termos técnicos e burocráticos.
        </p>
      </Card>

      <Card className="p-6 text-center flex flex-col items-center">
        <div className="bg-blue-100 p-4 rounded-full mb-4 dark:bg-blue-900">
          <CheckCircle className="h-10 w-10 text-blue-700 dark:text-blue-400" />
        </div>
        <h3 className="text-xl font-semibold mb-3">3. Receba a Explicação</h3>
        <p className="text-lg">
          Em segundos, você recebe uma explicação clara e simples do documento, em linguagem acessível.
        </p>
      </Card>
    </div>
  )
}
