import Link from "next/link"
import Image from "next/image"
import { Heart } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-gradient-to-b from-blue-50 via-gray-50 to-blue-100 dark:from-blue-50 dark:via-blue-900 dark:to-gray-900 border-t py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <Image src="/logo.png" alt="ExplicaBR Logo" width={180} height={54} className="h-12 w-auto" />
          </div>

          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8">
            <Link
              href="#"
              className="text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
            >
              Termos de Uso
            </Link>
            <Link
              href="#"
              className="text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
            >
              Política de Privacidade
            </Link>
            <Link
              href="#"
              className="text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
            >
              Contato
            </Link>
          </div>
        </div>

        <div className="mt-6 text-center">
          <p className="text-gray-600 flex items-center justify-center gap-1 dark:text-gray-300">
            Feito com <Heart className="h-4 w-4 text-red-500" /> para promover inclusão social e acessibilidade no
            Brasil
          </p>
          <p className="text-gray-500 mt-2 dark:text-gray-400">
            © {new Date().getFullYear()} ExplicaBR. Desenvolvido por{" "}
            <a href="https://github.com/millersantosbr" className="text-blue-600 hover:underline dark:text-blue-400">
              millersantosbr
            </a>{" "}
            com o auxílio do{" "}
            <a href="https://v0.dev" className="text-blue-600 hover:underline dark:text-blue-400">
              v0 da Vercel
            </a>
            . Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
