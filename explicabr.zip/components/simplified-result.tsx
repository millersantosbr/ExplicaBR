import { Card } from "@/components/ui/card"
import { FileText, AlertTriangle } from "lucide-react"

interface SimplifiedResultProps {
  originalText: string
  simplifiedText: string
  isDemo?: boolean
}

export function SimplifiedResult({ originalText, simplifiedText, isDemo }: SimplifiedResultProps) {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <h3 className="text-2xl font-semibold text-center">Resultado da Simplificação</h3>

      {isDemo && (
        <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg flex items-start gap-3 dark:bg-yellow-950/30 dark:border-yellow-800">
          <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-1 dark:text-yellow-400" />
          <div>
            <p className="text-yellow-800 font-medium dark:text-yellow-300">Modo de demonstração ativo</p>
            <p className="text-yellow-700 text-sm mt-1 dark:text-yellow-400">
              O serviço de IA está temporariamente indisponível devido a limitações de cota. Estamos mostrando um
              exemplo de simplificação similar ao seu texto.
            </p>
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-4 bg-gray-50 border-gray-300 dark:bg-gray-900 dark:border-gray-700">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="h-5 w-5 text-gray-700 dark:text-gray-300" />
            <h4 className="font-medium text-lg">Texto Original</h4>
          </div>
          <div className="text-gray-800 whitespace-pre-wrap dark:text-gray-200">{originalText}</div>
        </Card>

        <Card className="p-4 bg-blue-50 border-blue-200 dark:bg-blue-950/30 dark:border-blue-800">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="h-5 w-5 text-blue-700 dark:text-blue-400" />
            <h4 className="font-medium text-lg">Explicação Simplificada</h4>
          </div>
          <div className="text-blue-800 whitespace-pre-wrap dark:text-blue-300">{simplifiedText}</div>
        </Card>
      </div>
    </div>
  )
}
