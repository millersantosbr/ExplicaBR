"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2 } from "lucide-react"
import { SimplifiedResult } from "./simplified-result"
import { simplifyText } from "@/app/actions"

export function SimplifierForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<{
    originalText: string
    simplifiedText: string
  } | null>(null)

  async function handleSubmit(formData: FormData) {
    setIsLoading(true)
    setError(null)

    try {
      const response = await simplifyText(formData)

      if (response.success) {
        setResult({
          originalText: response.originalText,
          simplifiedText: response.simplifiedText,
        })
      } else {
        setError(response.error || "Ocorreu um erro ao processar seu texto.")
      }
    } catch (err) {
      setError("Ocorreu um erro ao processar seu texto. Por favor, tente novamente.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  function handleReset() {
    setResult(null)
    setError(null)
  }

  return (
    <div className="space-y-6">
      {!result ? (
        <form action={handleSubmit} className="space-y-6">
          <Textarea
            name="text"
            placeholder="Cole aqui o texto do documento que você quer entender..."
            className="min-h-[200px] text-lg p-4"
            required
            disabled={isLoading}
          />

          {error && <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg">{error}</div>}

          <div className="flex justify-center">
            <Button
              type="submit"
              size="lg"
              className="text-lg px-8 py-6 bg-blue-700 hover:bg-blue-800"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Simplificando...
                </>
              ) : (
                "Simplificar Documento"
              )}
            </Button>
          </div>
        </form>
      ) : (
        <div className="space-y-6">
          <SimplifiedResult originalText={result.originalText} simplifiedText={result.simplifiedText} />

          <div className="flex justify-center">
            <Button onClick={handleReset} size="lg" className="text-lg px-8 py-6">
              Simplificar Outro Documento
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
