import { Card } from "@/components/ui/card"
import { FileText } from "lucide-react"

export function SimplifiedTextDemo() {
  return (
    <div className="space-y-8">
      <h3 className="text-xl font-semibold text-center mb-4">
        Veja como transformamos textos complicados em explicações simples
      </h3>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-4 bg-gray-50 border-gray-300 dark:bg-gray-900 dark:border-gray-700">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="h-5 w-5 text-gray-700 dark:text-gray-300" />
            <h4 className="font-medium text-lg">Texto Original</h4>
          </div>
          <p className="text-gray-800 dark:text-gray-200">
            "Fica o requerente cientificado de que o prazo para interposição de recurso administrativo é de 30 (trinta)
            dias, a contar da data de ciência desta decisão, conforme disposto no art. 59 da Lei nº 9.784/99, sob pena
            de preclusão do direito."
          </p>
        </Card>

        <Card className="p-4 bg-blue-50 border-blue-200 dark:bg-blue-950/30 dark:border-blue-800">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="h-5 w-5 text-blue-700 dark:text-blue-400" />
            <h4 className="font-medium text-lg">Explicação Simplificada</h4>
          </div>
          <p className="text-blue-800 dark:text-blue-300">
            "Você tem 30 dias para recorrer desta decisão, contados a partir do dia em que você recebeu este aviso. Se
            não recorrer dentro deste prazo, você perderá o direito de contestar depois."
          </p>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-4 bg-gray-50 border-gray-300 dark:bg-gray-900 dark:border-gray-700">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="h-5 w-5 text-gray-700 dark:text-gray-300" />
            <h4 className="font-medium text-lg">Texto Original</h4>
          </div>
          <p className="text-gray-800 dark:text-gray-200">
            "O benefício previdenciário será suspenso quando o segurado não realizar o procedimento de prova de vida no
            prazo estipulado, conforme previsto no Art. 101 da Lei 8.213/91, com redação dada pela Lei 13.846/2019."
          </p>
        </Card>

        <Card className="p-4 bg-blue-50 border-blue-200 dark:bg-blue-950/30 dark:border-blue-800">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="h-5 w-5 text-blue-700 dark:text-blue-400" />
            <h4 className="font-medium text-lg">Explicação Simplificada</h4>
          </div>
          <p className="text-blue-800 dark:text-blue-300">
            "Seu benefício do INSS (como aposentadoria ou pensão) será temporariamente interrompido se você não fizer a
            prova de vida dentro do prazo informado. A prova de vida é quando você comprova que está vivo, geralmente
            indo ao banco ou usando aplicativos."
          </p>
        </Card>
      </div>
    </div>
  )
}
