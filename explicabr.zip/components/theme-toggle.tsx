"use client"

import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"

export function ThemeToggle() {
  const { setTheme } = useTheme()

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setTheme("light")}
        className="h-9 w-9 rounded-md"
        aria-label="Modo claro"
      >
        <Sun className="h-5 w-5" />
        <span className="sr-only">Modo claro</span>
      </Button>

      <Button
        variant="ghost"
        size="icon"
        onClick={() => setTheme("dark")}
        className="h-9 w-9 rounded-md"
        aria-label="Modo escuro"
      >
        <Moon className="h-5 w-5" />
        <span className="sr-only">Modo escuro</span>
      </Button>
    </>
  )
}
