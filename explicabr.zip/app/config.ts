// Configuração para acesso às variáveis de ambiente
export const config = {
  googleApiKey: process.env.GOOGLE_API_KEY_1 || "",
}

// Função para verificar se as configurações necessárias estão presentes
export function validateConfig() {
  const missingEnvVars = []

  if (!config.googleApiKey) {
    missingEnvVars.push("GOOGLE_API_KEY_1")
  }

  return {
    isValid: missingEnvVars.length === 0,
    missingEnvVars,
  }
}
