"use client"

import Link from "next/link"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, ArrowRight, FileCheck, Award, Lightbulb, HelpCircle, MessageSquare } from "lucide-react"
import { Footer } from "@/components/footer"
import { ThemeToggle } from "@/components/theme-toggle"

export default function ExamplesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b sticky top-0 bg-gradient-to-r from-blue-50 via-white to-blue-100 dark:from-blue-50 dark:via-blue-800 dark:to-gray-900 z-10">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center backdrop-blur-sm">
          <div className="flex items-center">
            <Link href="/">
              <Image
                src="/logo.png"
                alt="ExplicaBR Logo"
                width={240}
                height={72}
                className="h-12 md:h-16 w-auto"
                priority
              />
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <ThemeToggle />
            <nav>
              <ul className="flex gap-4 md:gap-6">
                <li>
                  <Link
                    href="/"
                    className="text-base md:text-lg text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
                  >
                    Início
                  </Link>
                </li>
                <li>
                  <Link
                    href="/exemplos"
                    className="text-base md:text-lg text-blue-700 font-semibold hover:text-blue-800 transition-colors dark:text-blue-300 dark:hover:text-white"
                  >
                    Exemplos
                  </Link>
                </li>
                <li>
                  <Link
                    href="/#como-funciona"
                    className="text-base md:text-lg text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
                  >
                    Como Funciona
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-blue-50 to-white py-8 md:py-16 dark:from-blue-900/30 dark:to-gray-900">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-blue-800 mb-4 dark:text-blue-300">
              Exemplos de Simplificação de Documentos
            </h1>
            <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto mb-8 dark:text-gray-300">
              Veja como o ExplicaBR pode transformar documentos complicados em explicações simples e fáceis de entender.
            </p>
          </div>
        </section>

        {/* Examples Section */}
        <section className="py-8 md:py-16">
          <div className="container mx-auto px-4 max-w-5xl">
            <div className="grid gap-12">
              {/* Example 1 - INSS */}
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 p-3 rounded-full dark:bg-blue-900">
                    <FileCheck className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                  </div>
                  <h2 className="text-2xl font-semibold text-blue-800 dark:text-blue-300">Notificação do INSS</h2>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="p-4 bg-gray-50 border-gray-300 dark:bg-gray-800 dark:border-gray-700">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                      <h3 className="font-medium text-lg">Texto Original</h3>
                    </div>
                    <p className="text-gray-800 dark:text-gray-200">
                      "Notificamos V.Sa. que, conforme disposto no art. 11 da Lei nº 10.666/2003 c/c art. 69 da Lei nº
                      8.212/1991, foi constatado em procedimento de auditoria que o benefício previdenciário nº
                      123.456.789-0 apresenta indícios de irregularidade. Fica o beneficiário notificado a comparecer à
                      Agência da Previdência Social para realização de perícia médica no prazo de 30 (trinta) dias a
                      contar do recebimento desta, sob pena de suspensão do benefício, nos termos do art. 101 da Lei nº
                      8.213/91."
                    </p>
                  </Card>

                  <Card className="p-4 bg-blue-50 border-blue-200 dark:bg-blue-900/30 dark:border-blue-800">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-blue-700 dark:text-blue-300" />
                      <h3 className="font-medium text-lg">Explicação Simplificada</h3>
                    </div>
                    <p className="text-blue-800 dark:text-blue-200">
                      "O INSS encontrou algo que parece errado no seu benefício (como aposentadoria ou auxílio-doença)
                      de número 123.456.789-0. Você precisa ir até uma agência do INSS para fazer uma perícia médica.
                      Você tem 30 dias para fazer isso, contando a partir do dia que recebeu esta carta. Se você não
                      for, seu benefício pode ser suspenso (ou seja, o pagamento será interrompido temporariamente)."
                    </p>
                  </Card>
                </div>
              </div>

              {/* Example 2 - Banco */}
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 p-3 rounded-full dark:bg-blue-900">
                    <FileCheck className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                  </div>
                  <h2 className="text-2xl font-semibold text-blue-800 dark:text-blue-300">Comunicado Bancário</h2>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="p-4 bg-gray-50 border-gray-300 dark:bg-gray-800 dark:border-gray-700">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                      <h3 className="font-medium text-lg">Texto Original</h3>
                    </div>
                    <p className="text-gray-800 dark:text-gray-200">
                      "Prezado(a) cliente, informamos que a partir do próximo ciclo de faturamento, haverá alteração na
                      política de tarifação de serviços bancários, conforme Resolução nº 3.919 do Banco Central do
                      Brasil. Os encargos referentes à manutenção de conta corrente e pacote de serviços sofrerão
                      reajuste de acordo com o IPCA acumulado no período. Para isenção das referidas tarifas, será
                      necessária a manutenção de investimentos com saldo médio mensal superior a R$ 30.000,00 ou
                      faturamento mensal em cartão de crédito acima de R$ 3.000,00."
                    </p>
                  </Card>

                  <Card className="p-4 bg-blue-50 border-blue-200 dark:bg-blue-900/30 dark:border-blue-800">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-blue-700 dark:text-blue-300" />
                      <h3 className="font-medium text-lg">Explicação Simplificada</h3>
                    </div>
                    <p className="text-blue-800 dark:text-blue-200">
                      "Olá, seu banco vai aumentar as taxas que cobra pelos serviços a partir do próximo mês. O aumento
                      será baseado na inflação (IPCA). Isso inclui a taxa de manutenção da sua conta e outros serviços
                      que você usa. Se você não quer pagar essas taxas, tem duas opções: 1) manter pelo menos R$
                      30.000,00 investidos no banco ou 2) gastar mais de R$ 3.000,00 por mês no cartão de crédito. Se
                      fizer uma dessas duas coisas, você não pagará as taxas."
                    </p>
                  </Card>
                </div>
              </div>

              {/* Example 3 - Judicial */}
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 p-3 rounded-full dark:bg-blue-900">
                    <FileCheck className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                  </div>
                  <h2 className="text-2xl font-semibold text-blue-800 dark:text-blue-300">Intimação Judicial</h2>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="p-4 bg-gray-50 border-gray-300 dark:bg-gray-800 dark:border-gray-700">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                      <h3 className="font-medium text-lg">Texto Original</h3>
                    </div>
                    <p className="text-gray-800 dark:text-gray-200">
                      "INTIMAÇÃO: Fica Vossa Senhoria devidamente intimado(a) para, querendo, apresentar contrarrazões
                      ao recurso interposto pela parte autora, no prazo legal de 15 (quinze) dias úteis, nos termos do
                      art. 1.010, §1º do Código de Processo Civil. Fica ainda cientificado(a) que a não manifestação
                      implicará no prosseguimento do feito, com remessa dos autos à instância superior para apreciação
                      do recurso, independentemente de juízo de admissibilidade, conforme disposto no §3º do mesmo
                      artigo."
                    </p>
                  </Card>

                  <Card className="p-4 bg-blue-50 border-blue-200 dark:bg-blue-900/30 dark:border-blue-800">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-blue-700 dark:text-blue-300" />
                      <h3 className="font-medium text-lg">Explicação Simplificada</h3>
                    </div>
                    <p className="text-blue-800 dark:text-blue-200">
                      "A pessoa que está processando você entrou com um recurso (ou seja, não concordou com a decisão do
                      juiz e pediu para que o caso seja reavaliado). Agora, você tem a chance de responder a esse
                      recurso, se quiser. Você tem 15 dias úteis (dias de semana, excluindo feriados) para fazer isso.
                      Se você não responder, o processo continuará normalmente e será enviado para juízes de instância
                      superior (como um tribunal) que vão analisar o recurso da outra parte."
                    </p>
                  </Card>
                </div>
              </div>

              {/* Example 4 - Contrato */}
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 p-3 rounded-full dark:bg-blue-900">
                    <FileCheck className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                  </div>
                  <h2 className="text-2xl font-semibold text-blue-800 dark:text-blue-300">Cláusula de Contrato</h2>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="p-4 bg-gray-50 border-gray-300 dark:bg-gray-800 dark:border-gray-700">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                      <h3 className="font-medium text-lg">Texto Original</h3>
                    </div>
                    <p className="text-gray-800 dark:text-gray-200">
                      "Cláusula 8.3 - Da Rescisão Contratual: O presente contrato poderá ser rescindido unilateralmente
                      por qualquer das partes mediante notificação prévia de 30 (trinta) dias, sem prejuízo do
                      cumprimento das obrigações pendentes. Em caso de rescisão antecipada por parte do CONTRATANTE,
                      este ficará obrigado ao pagamento de multa compensatória equivalente a 30% (trinta por cento) do
                      valor remanescente do contrato, calculado pro rata temporis, a título de perdas e danos
                      pré-fixados, sem prejuízo de eventuais perdas e danos suplementares."
                    </p>
                  </Card>

                  <Card className="p-4 bg-blue-50 border-blue-200 dark:bg-blue-900/30 dark:border-blue-800">
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="h-5 w-5 text-blue-700 dark:text-blue-300" />
                      <h3 className="font-medium text-lg">Explicação Simplificada</h3>
                    </div>
                    <p className="text-blue-800 dark:text-blue-200">
                      "Tanto você quanto a empresa podem cancelar este contrato, mas precisam avisar a outra parte com
                      30 dias de antecedência. Se você decidir cancelar o contrato antes do prazo final, terá que pagar
                      uma multa de 30% sobre o valor que ainda faltaria pagar até o fim do contrato. Por exemplo, se
                      ainda faltam 6 meses de um contrato de R$ 100 por mês (total de R$ 600), você teria que pagar uma
                      multa de R$ 180 (30% de R$ 600). Além disso, a empresa ainda pode cobrar outros valores se
                      comprovar que teve mais prejuízos com o cancelamento."
                    </p>
                  </Card>
                </div>
              </div>
            </div>

            {/* Nova seção: Perguntas do Dia a Dia */}
            <div className="mt-20">
              <div className="flex items-center gap-3 mb-8">
                <div className="bg-blue-100 p-3 rounded-full dark:bg-blue-900">
                  <MessageSquare className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                </div>
                <h2 className="text-2xl font-semibold text-blue-800 dark:text-blue-300">Perguntas do Dia a Dia</h2>
              </div>

              <p className="text-lg text-gray-700 mb-8 max-w-3xl dark:text-gray-300">
                Veja como o ExplicaBR pode ajudar com dúvidas comuns sobre seus direitos em situações cotidianas:
              </p>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Pergunta 1 - Hora Extra */}
                <Card className="p-5 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <div className="flex gap-3 mb-3">
                    <HelpCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5 dark:text-blue-400" />
                    <h3 className="font-medium text-lg text-gray-800 dark:text-gray-200">
                      "Meu chefe quer que eu faça hora extra mas ele não me avisou antes, como sair dessa situação?"
                    </h3>
                  </div>
                  <div className="ml-8">
                    <p className="text-gray-700 dark:text-gray-300">
                      De acordo com a CLT, seu chefe deve avisar sobre horas extras com antecedência. Você pode explicar
                      educadamente que precisa de aviso prévio para se organizar. Se for algo excepcional, você pode
                      negociar compensação adicional ou folga. Caso seja recorrente, documente os pedidos de última hora
                      e consulte o sindicato da sua categoria ou um advogado trabalhista.
                    </p>
                  </div>
                </Card>

                {/* Pergunta 2 - Aluguel */}
                <Card className="p-5 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <div className="flex gap-3 mb-3">
                    <HelpCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5 dark:text-blue-400" />
                    <h3 className="font-medium text-lg text-gray-800 dark:text-gray-200">
                      "O proprietário do imóvel que alugo quer aumentar o valor acima da inflação, ele pode fazer isso?"
                    </h3>
                  </div>
                  <div className="ml-8">
                    <p className="text-gray-700 dark:text-gray-300">
                      Não, durante a vigência do contrato, o proprietário só pode reajustar o aluguel uma vez por ano e
                      seguindo o índice previsto no contrato (geralmente IGP-M ou IPCA). Aumentos acima da inflação só
                      podem acontecer na renovação do contrato, e mesmo assim, devem refletir o valor de mercado. Se o
                      proprietário insistir, você pode procurar o Procon ou um advogado especializado.
                    </p>
                  </div>
                </Card>

                {/* Pergunta 3 - Compra Online */}
                <Card className="p-5 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <div className="flex gap-3 mb-3">
                    <HelpCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5 dark:text-blue-400" />
                    <h3 className="font-medium text-lg text-gray-800 dark:text-gray-200">
                      "Comprei um produto pela internet e me arrependi, posso devolver?"
                    </h3>
                  </div>
                  <div className="ml-8">
                    <p className="text-gray-700 dark:text-gray-300">
                      Sim! O Código de Defesa do Consumidor garante o direito de arrependimento em compras feitas fora
                      do estabelecimento comercial (internet, telefone, etc.). Você tem até 7 dias corridos após receber
                      o produto para desistir da compra, sem precisar explicar o motivo. Entre em contato com a loja,
                      informe sua desistência por escrito (e-mail ou chat) e guarde o protocolo. A empresa deve devolver
                      todo o valor pago, inclusive frete.
                    </p>
                  </div>
                </Card>

                {/* Pergunta 4 - Banco */}
                <Card className="p-5 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <div className="flex gap-3 mb-3">
                    <HelpCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5 dark:text-blue-400" />
                    <h3 className="font-medium text-lg text-gray-800 dark:text-gray-200">
                      "O banco cobrou uma taxa que eu não conhecia, o que faço?"
                    </h3>
                  </div>
                  <div className="ml-8">
                    <p className="text-gray-700 dark:text-gray-300">
                      Primeiro, verifique seu contrato para confirmar se a taxa está prevista. Os bancos só podem cobrar
                      taxas que estejam claramente informadas no contrato ou na tabela de tarifas. Se a taxa não estiver
                      prevista ou não foi informada previamente, você pode contestar. Entre em contato com o SAC do
                      banco, registre uma reclamação formal e peça o número de protocolo. Se não resolver, recorra à
                      Ouvidoria do banco e, se necessário, ao Banco Central ou Procon. Você tem direito à devolução em
                      dobro de valores cobrados indevidamente.
                    </p>
                  </div>
                </Card>

                {/* Pergunta 5 - Garantia */}
                <Card className="p-5 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <div className="flex gap-3 mb-3">
                    <HelpCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5 dark:text-blue-400" />
                    <h3 className="font-medium text-lg text-gray-800 dark:text-gray-200">
                      "Meu celular quebrou dentro da garantia mas a loja diz que foi mau uso, o que fazer?"
                    </h3>
                  </div>
                  <div className="ml-8">
                    <p className="text-gray-700 dark:text-gray-300">
                      A loja ou fabricante precisa provar que houve mau uso, não basta apenas afirmar. Solicite um laudo
                      técnico detalhado que comprove o que eles alegam. Se você discordar, pode pedir uma segunda
                      opinião técnica independente. Registre uma reclamação formal na loja (guarde o protocolo), no
                      Procon e no site Consumidor.gov.br. Se necessário, você pode entrar com uma ação no Juizado
                      Especial Cível (pequenas causas) sem precisar de advogado para valores até 20 salários mínimos.
                    </p>
                  </div>
                </Card>

                {/* Pergunta 6 - Demissão */}
                <Card className="p-5 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <div className="flex gap-3 mb-3">
                    <HelpCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5 dark:text-blue-400" />
                    <h3 className="font-medium text-lg text-gray-800 dark:text-gray-200">
                      "Fui demitido sem justa causa, quais são meus direitos?"
                    </h3>
                  </div>
                  <div className="ml-8">
                    <p className="text-gray-700 dark:text-gray-300">
                      Você tem direito a: 1) Aviso prévio (trabalhado ou indenizado) de 30 dias + 3 dias por ano
                      trabalhado; 2) Saldo de salário pelos dias trabalhados no mês; 3) Férias vencidas e proporcionais
                      com acréscimo de 1/3; 4) 13º salário proporcional; 5) Saque do FGTS + multa de 40% sobre todo o
                      valor depositado; 6) Seguro-desemprego (se trabalhou pelo menos 12 meses nos últimos 18 meses). A
                      empresa deve fazer o pagamento das verbas rescisórias em até 10 dias após o término do contrato.
                      Confira todos os valores na sua rescisão e, em caso de dúvidas, consulte o sindicato da sua
                      categoria.
                    </p>
                  </div>
                </Card>
              </div>
            </div>

            {/* Call to Action */}
            <div className="mt-16 text-center">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 md:p-8 max-w-3xl mx-auto dark:bg-blue-900/30 dark:border-blue-800">
                <div className="flex justify-center mb-4">
                  <div className="bg-blue-100 p-3 rounded-full dark:bg-blue-800">
                    <Lightbulb className="h-8 w-8 text-blue-700 dark:text-blue-300" />
                  </div>
                </div>
                <h2 className="text-2xl font-semibold text-blue-800 mb-4 dark:text-blue-300">
                  Experimente agora mesmo!
                </h2>
                <p className="text-lg text-gray-700 mb-6 dark:text-gray-300">
                  Tem um documento difícil de entender ou uma dúvida sobre seus direitos? Cole o texto ou faça sua
                  pergunta e deixe o ExplicaBR simplificar para você.
                </p>
                <Button
                  size="lg"
                  className="text-lg px-8 py-6 bg-blue-700 hover:bg-blue-800"
                  onClick={() => {
                    window.location.href = "/#simplificar"
                  }}
                >
                  Simplificar um Documento <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Benefits */}
            <div className="mt-16">
              <h2 className="text-2xl font-semibold text-blue-800 text-center mb-8 dark:text-blue-300">
                Como o ExplicaBR pode ajudar você
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                <Card className="p-6 text-center flex flex-col items-center dark:bg-gray-800 dark:border-gray-700">
                  <div className="bg-blue-100 p-4 rounded-full mb-4 dark:bg-blue-900">
                    <Award className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 dark:text-gray-200">Entenda seus direitos</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Compreenda documentos oficiais, notificações e comunicados do governo sem precisar de um advogado.
                  </p>
                </Card>

                <Card className="p-6 text-center flex flex-col items-center dark:bg-gray-800 dark:border-gray-700">
                  <div className="bg-blue-100 p-4 rounded-full mb-4 dark:bg-blue-900">
                    <Award className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 dark:text-gray-200">Tome decisões informadas</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Entenda contratos, termos de uso e documentos financeiros antes de assinar ou concordar com eles.
                  </p>
                </Card>

                <Card className="p-6 text-center flex flex-col items-center dark:bg-gray-800 dark:border-gray-700">
                  <div className="bg-blue-100 p-4 rounded-full mb-4 dark:bg-blue-900">
                    <Award className="h-6 w-6 text-blue-700 dark:text-blue-300" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 dark:text-gray-200">Economize tempo e dinheiro</h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    Evite consultas desnecessárias a profissionais apenas para entender documentos simples.
                  </p>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
