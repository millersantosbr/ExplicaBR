"use server"

import { generateText } from "ai"
import { createGoogleGenerativeAI } from "@ai-sdk/google"
import { config, validateConfig } from "./config"
import { findSimilarExample } from "./demo-examples"

// Cache simples para armazenar resultados recentes
const simplificationCache = new Map<string, { originalText: string; simplifiedText: string }>()

// Função auxiliar para converter arquivo em base64
async function fileToBase64(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer()
  const bytes = new Uint8Array(arrayBuffer)
  let binary = ""
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  return btoa(binary)
}

// Prompt para extração de texto de documentos e imagens
const extractionPrompt = `
  Você está analisando um documento que foi anexado. 
  Por favor, extraia todo o texto visível deste documento e forneça-o em formato de texto simples.
  Se for uma imagem, descreva detalhadamente o que você vê e qualquer texto presente na imagem.
  Se for um PDF, extraia todo o conteúdo textual.

  NÃO use formatação Markdown como asteriscos (*), numeração (#), ou outros marcadores em sua resposta.
  Forneça o texto em formato simples, sem marcadores especiais.
  
  Concentre-se apenas na extração do conteúdo, sem fazer análises ou simplificações neste momento.
`

// Prompt para explicação e simplificação do texto extraído
const explanationPrompt = `
  Você é um assistente de inteligência artificial especializado na simplificação da linguagem burocrática e jurídica do Brasil. Seu principal objetivo é tornar informações complexas acessíveis a indivíduos com baixa escolaridade e nenhum conhecimento técnico ou jurídico prévio.

  **Instruções Detalhadas:**

  1.  **Atue como um tradutor especializado:** Ao receber um texto em linguagem burocrática, analise-o minuciosamente com o objetivo de identificar todos os termos técnicos, jargões específicos, construções frasais complexas e referências legais que possam dificultar a compreensão por um público leigo.

  2.  **Adote uma persona de comunicador acessível:** Ao explicar o conteúdo, posicione-se como um interlocutor amigável e paciente, utilizando uma linguagem coloquial e descontraída, similar a uma conversa informal entre amigos.

  3.  **Priorize a clareza e a simplicidade:**
      * **Use frases curtas e diretas:** Evite orações subordinadas longas e períodos complexos. Divida ideias complexas em afirmações simples e concisas.
      * **Substitua jargões e termos técnicos:** Identifique palavras como "adimplemento", "exequibilidade", "interposição de recurso" e troque-as por equivalentes acessíveis como "pagamento", "poder de ser cobrado na justiça", "entrar com um pedido de revisão".
      * **Evite siglas e abreviações:** Caso seja imprescindível utilizá-las, explique o significado completo na primeira menção.
      * **Elimine redundâncias e formalidades excessivas:** Vá direto ao ponto, sem rodeios ou expressões desnecessariamente formais como "destarte", "outrossim", "em face do exposto".
      * **Mantenha a resposta concisa:** Busque explicar o conteúdo de forma completa, mas evite informações desnecessárias ou excessivamente detalhadas. O objetivo é a clareza e a compreensão rápida.

  4.  **Contextualize e exemplifique:**
      * **Forneça exemplos práticos:** Ilustre conceitos abstratos ou situações legais com exemplos do cotidiano para facilitar a visualização e o entendimento. Por exemplo, ao explicar um artigo de lei sobre "venda e compra de bens móveis", cite a compra de um carro ou de um eletrodoméstico.
      * **Crie analogias e metáforas:** Utilize comparações com situações familiares ao público para tornar ideias complexas mais palatáveis.
      * **Explique o propósito e a implicação:** Não apenas traduza as palavras, mas também explique o significado e a consequência prática da informação para a vida do cidadão comum.

  5.  **Mantenha um tom respeitoso e empático:** Demonstre consideração pela possível falta de conhecimento prévio do usuário, evitando qualquer tom condescendente ou que possa intimidar.

  6.  **Organize a informação de forma lógica:** Estruture a explicação de maneira sequencial e clara, facilitando o acompanhamento do raciocínio. Utilize marcadores ou outros recursos visuais simples, se apropriado.

  7.  **Verifique a compreensão:** Ao final da explicação, convide o usuário a fazer perguntas e ofereça-se para esclarecer quaisquer dúvidas que possam ter surgido.

  IMPORTANTE: NÃO use formatação Markdown como asteriscos (*), hashes (#), ou outros marcadores em sua resposta.
  Forneça o texto em formato simples, sem marcadores especiais.
  Se precisar criar listas, use números ou letras seguidos de ponto (1. ou a.) sem formatação especial.
  Se precisar destacar algo, use apenas letras maiúsculas ou frases como "Importante:" no início do parágrafo.
  
  Texto original:
  "{textToSimplify}"
  
  Explicação:
`

// Função para processar o documento anexado - ETAPA 1: EXTRAÇÃO
async function processAttachedDocument(file: File): Promise<string> {
  try {
    console.log("Processando documento anexado:", file.name, file.type)

    // Validar configuração
    const configValidation = validateConfig()
    if (!configValidation.isValid) {
      console.warn(
        `Configuração inválida. Variáveis de ambiente ausentes: ${configValidation.missingEnvVars.join(", ")}.`,
      )
      throw new Error("Configuração do serviço incompleta.")
    }

    // Criar uma instância personalizada do cliente Google Generative AI
    const googleAI = createGoogleGenerativeAI({
      apiKey: config.googleApiKey,
    })

    // Converter o arquivo para um ArrayBuffer
    const arrayBuffer = await file.arrayBuffer()

    console.log("Enviando documento para a API do Google para extração de texto...")

    // Usando o método alternativo para processar imagens
    // Primeiro, vamos verificar se é uma imagem
    if (file.type.startsWith("image/")) {
      // Para imagens, usamos o método específico para imagens
      const { text: extractedContent } = await generateText({
        model: googleAI("gemini-2.0-flash"),
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: extractionPrompt,
              },
              {
                type: "image",
                image: new Uint8Array(arrayBuffer),
              },
            ],
          },
        ],
        temperature: 0.1,
        maxTokens: 1500,
      })

      console.log("Texto extraído da imagem anexada")
      return extractedContent
    } else {
      // Para outros tipos de arquivo (como PDFs), usamos uma abordagem diferente
      // Como o Gemini não processa PDFs diretamente, vamos retornar uma mensagem informativa
      return "[Este é um documento PDF. Atualmente, o sistema não pode extrair texto diretamente de PDFs. Por favor, copie e cole o texto do documento manualmente para obter melhores resultados.]"
    }
  } catch (error) {
    console.error("Erro ao processar documento anexado:", error)
    throw new Error("Não foi possível processar o documento anexado. Por favor, tente novamente.")
  }
}

// Função para simplificar o texto - ETAPA 2: EXPLICAÇÃO
async function simplifyExtractedText(textToSimplify: string): Promise<string> {
  try {
    console.log("Simplificando texto extraído...")

    // Validar configuração
    const configValidation = validateConfig()
    if (!configValidation.isValid) {
      console.warn(
        `Configuração inválida. Variáveis de ambiente ausentes: ${configValidation.missingEnvVars.join(", ")}. Usando modo de demonstração.`,
      )
      throw new Error("Configuração do serviço incompleta.")
    }

    // Criar uma instância personalizada do cliente Google Generative AI
    const googleAI = createGoogleGenerativeAI({
      apiKey: config.googleApiKey,
    })

    // Substituir o placeholder no prompt de explicação
    const finalPrompt = explanationPrompt.replace("{textToSimplify}", textToSimplify)

    // Usando a instância personalizada do cliente com o modelo gemini-2.0-flash
    const { text: simplifiedText } = await generateText({
      model: googleAI("gemini-2.0-flash"),
      messages: [
        {
          role: "user",
          content: finalPrompt,
        },
      ],
      temperature: 0.3,
      maxTokens: 1500,
    })

    console.log("Texto simplificado com sucesso")
    return simplifiedText
  } catch (error) {
    console.error("Erro ao simplificar texto extraído:", error)
    throw new Error("Não foi possível simplificar o texto. Por favor, tente novamente.")
  }
}

// Função principal que coordena o processo completo
export async function simplifyText(prevState: any, formData: FormData) {
  try {
    const text = formData.get("text") as string
    const documentFile = formData.get("document") as File | null

    let textToProcess = text || ""

    // ETAPA 1: Se tiver um arquivo anexado, extrair o texto
    if (documentFile && documentFile.size > 0) {
      try {
        console.log("Documento anexado detectado:", documentFile.name, documentFile.type)
        const extractedText = await processAttachedDocument(documentFile)

        // Se não houver texto inserido manualmente, usa o texto extraído do documento
        // Caso contrário, mantém o texto inserido pelo usuário
        if (!text || text.trim().length === 0) {
          textToProcess = extractedText
        }

        console.log("Texto extraído do documento:", textToProcess.substring(0, 100) + "...")
      } catch (error) {
        console.error("Erro ao processar documento:", error)
        return {
          success: false,
          error:
            "Não foi possível processar o documento anexado. Por favor, tente novamente ou cole o texto diretamente.",
          originalText: "",
          simplifiedText: "",
        }
      }
    }

    if (!textToProcess || textToProcess.trim().length === 0) {
      return {
        success: false,
        error: "Por favor, insira um texto ou anexe um documento para simplificar.",
        originalText: "",
        simplifiedText: "",
      }
    }

    try {
      // ETAPA 2: Simplificar o texto extraído ou inserido pelo usuário
      const simplifiedText = await simplifyExtractedText(textToProcess)

      // Armazenar o resultado no cache
      const cacheKey = textToProcess
      simplificationCache.set(cacheKey, {
        originalText: textToProcess,
        simplifiedText,
      })

      return {
        success: true,
        originalText: textToProcess,
        simplifiedText,
        error: null,
      }
    } catch (error) {
      console.warn("Erro ao chamar a API do Google. Usando modo de demonstração.", error)

      // Usar o modo de demonstração quando a API falhar
      const demoResult = findSimilarExample(textToProcess)

      return {
        success: true,
        originalText: textToProcess,
        simplifiedText: `${demoResult.simplified}\n\n[Nota: Esta é uma resposta de demonstração. O serviço de IA está temporariamente indisponível devido a limitações de cota.]`,
        error: null,
        isDemo: true,
      }
    }
  } catch (error) {
    console.error("Erro ao simplificar texto:", error)
    return {
      success: false,
      error: "Ocorreu um erro ao processar seu texto. Por favor, tente novamente mais tarde.",
      originalText: "",
      simplifiedText: "",
    }
  }
}
