"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, HelpCircle, Info, Loader2, AlertTriangle, Menu } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { SimplifiedTextDemo } from "@/components/simplified-text-demo"
import { HowItWorks } from "@/components/how-it-works"
import { Footer } from "@/components/footer"
import { SimplifiedResult } from "@/components/simplified-result"
import { simplifyText } from "./actions"
import { useActionState } from "react"
import { Textarea } from "@/components/ui/textarea"
import { useState, useRef } from "react"
import { FileUp, FileText, X } from "lucide-react"
import { useMediaQuery } from "@/hooks/use-media-query"
// Adicione a importação do ThemeToggle
import { ThemeToggle } from "@/components/theme-toggle"

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false)
  const isMobile = useMediaQuery("(max-width: 768px)")

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b sticky top-0 bg-gradient-to-r from-blue-50 via-white to-blue-100 dark:from-blue-50 dark:via-blue-800 dark:to-gray-900 z-10">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center backdrop-blur-sm">
          <div className="flex items-center">
            <Image
              src="/logo.png"
              alt="ExplicaBR Logo"
              width={240}
              height={72}
              className="h-12 md:h-16 w-auto"
              priority
            />
          </div>

          <div className="flex items-center gap-4">
            <ThemeToggle />

            {isMobile ? (
              <div className="relative">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setMenuOpen(!menuOpen)}
                  aria-label="Menu de navegação"
                >
                  <Menu className="h-6 w-6" />
                </Button>

                {menuOpen && (
                  <div className="absolute right-0 top-full mt-2 bg-white shadow-lg rounded-lg p-4 w-48 border">
                    <nav>
                      <ul className="flex flex-col gap-4">
                        <li>
                          <Link
                            href="/exemplos"
                            className="text-lg text-gray-700 hover:text-blue-700 transition-colors block py-1"
                            onClick={() => setMenuOpen(false)}
                          >
                            Exemplos
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="#como-funciona"
                            className="text-lg text-gray-700 hover:text-blue-700 transition-colors block py-1"
                            onClick={() => setMenuOpen(false)}
                          >
                            Como Funciona
                          </Link>
                        </li>
                        <li>
                          <Link
                            href="#sobre"
                            className="text-lg text-gray-700 hover:text-blue-700 transition-colors block py-1"
                            onClick={() => setMenuOpen(false)}
                          >
                            Sobre
                          </Link>
                        </li>
                      </ul>
                    </nav>
                  </div>
                )}
              </div>
            ) : (
              <nav>
                <ul className="flex gap-6">
                  <li>
                    <Link
                      href="/exemplos"
                      className="text-lg text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
                    >
                      Exemplos
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#como-funciona"
                      className="text-lg text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
                    >
                      Como Funciona
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="#sobre"
                      className="text-lg text-gray-700 hover:text-blue-700 transition-colors dark:text-blue-100 dark:hover:text-white"
                    >
                      Sobre
                    </Link>
                  </li>
                </ul>
              </nav>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-blue-50 to-white py-8 md:py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold text-blue-800 mb-4 md:mb-6">
              Transformamos textos e documentos burocráticos em linguagem simples para você entender
            </h2>
            <p className="text-lg md:text-2xl text-gray-700 max-w-3xl mx-auto mb-6 md:mb-8">
              ExplicaBR ajuda você a entender documentos oficiais, cartas do INSS, contratos bancários, comunicados do
              governo e outros textos, tudo de forma clara e acessível.
            </p>
            <Button
              size={isMobile ? "default" : "lg"}
              className={`text-base md:text-lg px-6 py-2 md:px-8 md:py-6 bg-blue-700 hover:bg-blue-800 ${
                isMobile ? "w-full" : ""
              }`}
              onClick={() => {
                document.getElementById("simplificar")?.scrollIntoView({ behavior: "smooth" })
              }}
            >
              Comece Agora <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>

        {/* Main Tool Section */}
        <section id="simplificar" className="py-8 md:py-16">
          <div className="container mx-auto px-4">
            <Card className="p-4 md:p-8 shadow-lg max-w-4xl mx-auto">
              <h3 className="text-xl md:text-3xl font-semibold text-center mb-4 md:mb-6">
                Cole o texto ou anexe seu documento abaixo
              </h3>
              <p className="text-gray-600 text-center mb-6 md:mb-8 text-base md:text-lg">
                Nosso sistema vai transformar o texto complicado em uma explicação simples e fácil de entender
              </p>

              <Tabs defaultValue="simplificar" className="w-full flex flex-col items-center">
                <TabsList className="w-full max-w-md mx-auto mb-6 md:mb-8 p-1 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden border border-gray-200 dark:border-gray-700 shadow-sm">
                  <TabsTrigger
                    value="simplificar"
                    className="text-base md:text-lg py-2.5 md:py-3 px-4 rounded-full font-medium transition-all duration-200 data-[state=active]:bg-white data-[state=active]:text-blue-700 data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-900 dark:data-[state=active]:text-blue-400"
                  >
                    Simplificar Texto
                  </TabsTrigger>
                  <TabsTrigger
                    value="exemplos"
                    className="text-base md:text-lg py-2.5 md:py-3 px-4 rounded-full font-medium transition-all duration-200 data-[state=active]:bg-white data-[state=active]:text-blue-700 data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-900 dark:data-[state=active]:text-blue-400"
                  >
                    Ver Exemplos
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="simplificar" className="space-y-4 md:space-y-6">
                  <SimplifierForm />

                  <div className="bg-blue-50 p-3 md:p-4 rounded-lg flex items-start gap-2 md:gap-3">
                    <Info className="h-5 w-5 text-blue-700 flex-shrink-0 mt-1" />
                    <p className="text-sm md:text-base text-blue-800">
                      Seus documentos são processados com segurança. Não armazenamos o conteúdo dos seus textos após a
                      simplificação.
                    </p>
                  </div>
                </TabsContent>

                <TabsContent value="exemplos">
                  <SimplifiedTextDemo />
                  <div className="mt-6 text-center">
                    <Link href="/exemplos">
                      <Button variant="outline" className="mt-4">
                        Ver mais exemplos <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>
          </div>
        </section>

        {/* How It Works Section */}
        <section id="como-funciona" className="py-8 md:py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 md:mb-12 text-blue-800">Como Funciona</h2>
            <HowItWorks />
          </div>
        </section>

        {/* About Section */}
        <section id="sobre" className="py-8 md:py-16">
          <div className="container mx-auto px-4 max-w-4xl">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-6 md:mb-8 text-blue-800">Sobre o ExplicaBR</h2>
            <div className="space-y-4 md:space-y-6 text-base md:text-lg">
              <p>
                O ExplicaBR nasceu para resolver um problema sério no Brasil: a exclusão social causada pela linguagem
                técnica, jurídica e burocrática utilizada em documentos oficiais.
              </p>
              <p>
                A maioria das pessoas comuns não consegue entender boletos, cartas do INSS, contratos bancários,
                comunicados governamentais e outros documentos importantes que afetam suas vidas.
              </p>
              <p>
                Nossa plataforma gratuita e acessível permite que qualquer pessoa cole o texto de um documento oficial e
                receba uma explicação simples, clara e humanizada, com o poder da inteligência artificial.
              </p>
              <p>
                Nosso foco é a acessibilidade digital, a inclusão e o impacto social direto, ajudando pessoas com baixa
                escolaridade ou pouca familiaridade com termos jurídicos a exercerem plenamente sua cidadania.
              </p>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-8 md:py-16 bg-blue-50">
          <div className="container mx-auto px-4 max-w-4xl">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-6 md:mb-8 text-blue-800">
              Perguntas Frequentes
            </h2>

            <div className="space-y-4 md:space-y-6">
              <Card className="p-4 md:p-6">
                <h3 className="text-lg md:text-xl font-semibold mb-2 flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-blue-700" />O serviço é realmente gratuito?
                </h3>
                <p className="text-base md:text-lg">
                  Sim, o ExplicaBR é totalmente gratuito. Nossa missão é promover a inclusão social e a acessibilidade
                  da informação para todos os brasileiros.
                </p>
              </Card>

              <Card className="p-4 md:p-6">
                <h3 className="text-lg md:text-xl font-semibold mb-2 flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-blue-700" />
                  Meus documentos estão seguros?
                </h3>
                <p className="text-base md:text-lg">
                  Sim. Não armazenamos o conteúdo dos seus documentos após o processamento. Sua privacidade é nossa
                  prioridade.
                </p>
              </Card>

              <Card className="p-4 md:p-6">
                <h3 className="text-lg md:text-xl font-semibold mb-2 flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-blue-700" />
                  Que tipos de documentos posso simplificar?
                </h3>
                <p className="text-base md:text-lg">
                  Você pode simplificar qualquer texto de documento oficial, como cartas do INSS, contratos bancários,
                  notificações judiciais, comunicados governamentais, entre outros.
                </p>
              </Card>

              <Card className="p-4 md:p-6">
                <h3 className="text-lg md:text-xl font-semibold mb-2 flex items-center gap-2">
                  <HelpCircle className="h-5 w-5 text-blue-700" />
                  Como funciona a tecnologia por trás do ExplicaBR?
                </h3>
                <p className="text-base md:text-lg">
                  Utilizamos inteligência artificial avançada (API Gemini) para analisar o texto complexo e
                  transformá-lo em uma linguagem simples e acessível, mantendo o significado original.
                </p>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

function SimplifierForm() {
  const initialState = {
    success: false,
    error: null,
    originalText: "",
    simplifiedText: "",
    isDemo: false,
  }

  const [state, formAction, isPending] = useActionState(simplifyText, initialState)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [filePreview, setFilePreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isPdf, setIsPdf] = useState(false)
  const isMobile = useMediaQuery("(max-width: 768px)")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files)
      setSelectedFiles(files)

      // Verificar se é um PDF
      setIsPdf(files[0].type === "application/pdf")

      // Se for uma imagem, criar preview
      if (files[0].type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = () => {
          setFilePreview(reader.result as string)
        }
        reader.readAsDataURL(files[0])
      } else {
        // Se for PDF, mostrar ícone
        setFilePreview(null)
      }
    }
  }

  const removeFile = () => {
    setSelectedFiles([])
    setFilePreview(null)
    setIsPdf(false)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <form action={formAction} className="space-y-4">
      <div className="space-y-2">
        <Textarea
          placeholder="Cole aqui o texto do documento que você quer entender..."
          className="min-h-[150px] md:min-h-[200px] text-base md:text-lg p-3 md:p-4"
          name="text"
          aria-invalid={state?.error ? true : undefined}
        />

        <div className="flex items-center gap-2 text-sm text-gray-500">
          <span>ou</span>
          <div className="flex-1 border-t border-gray-200"></div>
        </div>

        <div className="flex flex-col gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <Button
              type="button"
              variant="outline"
              className="flex items-center gap-2 text-sm md:text-base py-1 px-3 h-auto"
              onClick={() => fileInputRef.current?.click()}
            >
              <FileUp size={16} />
              Anexar documento
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,image/*"
              onChange={handleFileChange}
              className="hidden"
              name="document"
            />
            <span className="text-xs md:text-sm text-gray-500">Formatos aceitos: PDF, JPG, PNG</span>
          </div>

          {isPdf && (
            <div className="bg-yellow-50 border border-yellow-200 p-2 md:p-3 rounded-md flex items-start gap-2 mt-2">
              <AlertTriangle className="h-4 w-4 md:h-5 md:w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs md:text-sm text-yellow-700">
                Atualmente, o processamento de PDFs está limitado. Para melhores resultados, recomendamos copiar e colar
                o texto diretamente.
              </p>
            </div>
          )}

          {selectedFiles.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 p-2 border rounded-md bg-gray-50">
                {filePreview ? (
                  <div className="relative h-12 w-12 md:h-16 md:w-16 overflow-hidden rounded-md">
                    <Image src={filePreview || "/placeholder.svg"} alt="Preview" fill className="object-cover" />
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-12 w-12 md:h-16 md:w-16 bg-gray-100 rounded-md">
                    <FileText size={20} className="text-blue-700" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-xs md:text-sm font-medium truncate">{selectedFiles[0].name}</p>
                  <p className="text-xs text-gray-500">{(selectedFiles[0].size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
                <Button type="button" variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={removeFile}>
                  <X size={16} />
                  <span className="sr-only">Remover arquivo</span>
                </Button>
              </div>

              <div className="bg-blue-50 border border-blue-200 p-2 md:p-3 rounded-md flex items-start gap-2">
                <Info className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-xs md:text-sm text-blue-700">
                  <p className="font-medium mb-1">Dicas para melhor processamento de imagens:</p>
                  <ul className="list-disc pl-4 md:pl-5 space-y-1">
                    <li>Adicione uma pergunta específica sobre o conteúdo da imagem</li>
                    <li>
                      Exemplo: "Simplifique o texto desta notificação judicial" em vez de apenas "O que tem nesta
                      imagem?"
                    </li>
                    <li>Se a imagem contém texto, mencione isso na sua pergunta</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {state?.error && (
        <p className="text-red-500 text-xs md:text-sm" aria-live="assertive">
          {state.error}
        </p>
      )}

      <Button
        type="submit"
        size={isMobile ? "default" : "lg"}
        className={`text-base md:text-lg px-4 py-2 md:px-8 md:py-6 bg-blue-700 hover:bg-blue-800 w-full relative ${
          isMobile ? "h-auto py-3" : ""
        }`}
        disabled={isPending}
      >
        {isPending ? (
          <>
            Simplificando...
            <Loader2 className="ml-2 h-4 w-4 animate-spin absolute right-4 top-1/2 -translate-y-1/2" />
          </>
        ) : (
          "Simplificar Conteúdo"
        )}
      </Button>

      {state?.success && (
        <SimplifiedResult
          originalText={state.originalText}
          simplifiedText={state.simplifiedText}
          isDemo={state.isDemo}
        />
      )}
    </form>
  )
}
