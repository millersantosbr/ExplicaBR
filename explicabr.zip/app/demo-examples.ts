// Exemplos de simplificação para usar quando a API não estiver disponível
export const demoExamples = [
  {
    original:
      "Fica o requerente cientificado de que o prazo para interposição de recurso administrativo é de 30 (trinta) dias, a contar da data de ciência desta decisão, conforme disposto no art. 59 da Lei nº 9.784/99, sob pena de preclusão do direito.",
    simplified:
      "Você tem 30 dias para recorrer desta decisão, contados a partir do dia em que você recebeu este aviso. Se não recorrer dentro deste prazo, você perderá o direito de contestar depois.",
  },
  {
    original:
      "O benefício previdenciário será suspenso quando o segurado não realizar o procedimento de prova de vida no prazo estipulado, conforme previsto no Art. 101 da Lei 8.213/91, com redação dada pela Lei 13.846/2019.",
    simplified:
      "Seu benefício do INSS (como aposentadoria ou pensão) será temporariamente interrompido se você não fizer a prova de vida dentro do prazo informado. A prova de vida é quando você comprova que está vivo, geralmente indo ao banco ou usando aplicativos.",
  },
  {
    original:
      "Informamos que o não comparecimento à perícia médica agendada para o dia XX/XX/XXXX, às XX:XX horas, acarretará a suspensão do benefício por incapacidade, nos termos do art. 101 da Lei nº 8.213/91.",
    simplified:
      "Se você não comparecer à consulta médica marcada para o dia XX/XX/XXXX, às XX:XX horas, seu benefício por doença ou incapacidade será suspenso (interrompido temporariamente).",
  },
]

// Função para verificar se um texto é similar a algum dos exemplos
export function findSimilarExample(text: string): { original: string; simplified: string } | null {
  // Simplificar o texto para comparação (remover espaços extras, pontuação, etc.)
  const simplifiedText = text.toLowerCase().trim()

  // Verificar se o texto contém palavras-chave de algum dos exemplos
  for (const example of demoExamples) {
    const keywords = [
      "prazo",
      "recurso",
      "benefício",
      "previdenciário",
      "perícia",
      "suspensão",
      "prova de vida",
      "comparecimento",
    ]

    // Se o texto contiver pelo menos 2 palavras-chave do exemplo, consideramos similar
    const matchCount = keywords.filter((keyword) => simplifiedText.includes(keyword)).length
    if (matchCount >= 2) {
      return example
    }
  }

  // Se não encontrar nenhum exemplo similar, retornar o primeiro exemplo como fallback
  return demoExamples[0]
}
